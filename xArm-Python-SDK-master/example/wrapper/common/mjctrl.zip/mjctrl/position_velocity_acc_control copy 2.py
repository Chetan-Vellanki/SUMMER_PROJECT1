import mujoco
import mujoco.viewer
import numpy as np
import time
import threading
import matplotlib.pyplot as plt

# Integration timestep in seconds. This corresponds to the amount of time the joint
# velocities will be integrated for to obtain the desired joint positions.
integration_dt: float = 0.2

# Damping ratio for both Cartesian and joint impedance control.
damping_ratio = 1.0

# Damping term for the pseudoinverse. This is used to prevent joint velocities from
# becoming too large when the Jacobian is close to singular.
damping: float = 1e-4

# Gains for the twist computation. These should be between 0 and 1. 0 means no
# movement, 1 means move the end-effector to the target in one integration step.
Kpos: float = 0.95
Kori: float = 0.95

# Whether to enable gravity compensation.
gravity_compensation: bool = True

# Simulation timestep in seconds.
dt: float = 0.002
time_to_achieve_desired_position = integration_dt

# Nullspace P gain.
Kn = np.asarray([10.0, 10.0, 10.0, 10.0, 5.0, 5.0, 5.0])

# Maximum allowable joint velocity in rad/s.
max_angvel = 0.785

# PD control gains
Kp = 50  # Proportional gain
Kd = 10  # Derivative gain
Ki = 0.01
# Target positions array.
target_positions = [np.array([0.32, 0, 0.32])]
number_of_simulation_steps = integration_dt / dt

def user_input_thread():
    global target_positions
    x = float(input("Enter target x position: "))
    y = float(input("Enter target y position: "))
    z = float(input("Enter target z position: "))
    new_position = np.array([x, y, z])
    target_positions.append(new_position)

def main() -> None:
    assert mujoco.__version__ >= "3.1.0", "Please upgrade to mujoco 3.1.0 or later."

    # Load the model and data.
    model = mujoco.MjModel.from_xml_path("ufactory_xarm7/scene_strike_act.xml")
    data = mujoco.MjData(model)

    # Enable gravity compensation. Set to 0.0 to disable.
    model.body_gravcomp[:17] = float(gravity_compensation)
    model.opt.timestep = dt

    # End-effector site we wish to control.
    site_name = "link_tcp"
    site_id = model.site(site_name).id
    print("site_id: ", site_id)

    # Get the dof and actuator ids for the joints we wish to control. These are copied
    # from the XML file. Feel free to comment out some joints to see the effect on
    # the controller.
    joint_names = [
        "joint1",
        "joint2",
        "joint3",
        "joint4",
        "joint5",
        "joint6",
        "joint7",
    ]
    dof_ids = np.array([model.joint(name).id for name in joint_names])
    actuator_ids = np.array([model.actuator(name).id for name in joint_names])
    print("dof_ids: ", dof_ids)

    # Initial joint configuration saved as a keyframe in the XML file.
    key_name = "home"
    key_id = model.key(key_name).id
    q0 = model.key(key_name).qpos
    #only till joints
    q01 = q0[:7]
    print("keyid:", key_id)
    print("qo:", q0)

    # Mocap body we will control with our mouse.
    mocap_name = "target"
    mocap_id = model.body(mocap_name).mocapid[0]
    
    current_waypoint_index = 0

    # Pre-allocate numpy arrays.
    jac = np.zeros((6, model.nv))
    diag = damping * np.eye(7)
    eye = np.eye(7)
    twist = np.zeros(6)
    site_quat = np.zeros(4)
    site_quat_conj = np.zeros(4)
    error_quat = np.zeros(4)
    Kvel = 0.5
    M_inv = np.array((model.nv, model.nv))

    # Start the user input thread.
    velocity_in_x = []
    velocity_in_y = []
    velocity_in_z = []
    time_axis_index = []
    time_start = time.time()
    previous_time = time.time()
    previous_error = np.zeros(3)
    with mujoco.viewer.launch_passive(
        model=model,
        data=data,
        show_left_ui=False,
        show_right_ui=False,
    ) as viewer:
        time_start = time.time()
        # Reset the simulation.
        mujoco.mj_resetDataKeyframe(model, data, key_id)

        # Reset the free camera.
        mujoco.mjv_defaultFreeCamera(model, viewer.cam)

        # Enable site frame visualization.
        viewer.opt.frame = mujoco.mjtFrame.mjFRAME_SITE
        q11 = []
        
        index_time = 0
        
        while viewer.is_running():
            
            step_start = time.time()
            initial_position = data.site(site_id).xpos.copy()

            # Spatial velocity (aka twist).
            current_waypoint = target_positions[current_waypoint_index]
            dx = current_waypoint - data.site(site_id).xpos
            print("dx : ", np.linalg.norm(dx))

            if np.linalg.norm(dx) < 0.01:  # Tolerance of 1 cm to consider as reached
                user_input_thread()
                time_start = time.time()
                current_waypoint_index += 1
                if current_waypoint_index >= len(target_positions):
                    current_waypoint_index = 0 
            
            if(current_waypoint_index == 0) : 
                current_target_position = initial_position
                print("Initial position : ", initial_position)
            if(current_waypoint_index >= 1) :
                current_target_position = target_positions[current_waypoint_index - 1]
            new_target_position = target_positions[current_waypoint_index]
            delta_position_vector = new_target_position - current_target_position
            distance_to_travel = np.linalg.norm(new_target_position - current_target_position)
            displacement_in_x = delta_position_vector[0]
            displacement_in_y = delta_position_vector[1]
            displacement_in_z = delta_position_vector[2]
            time_to_travel = time_to_achieve_desired_position

            print("waypoint index : ", current_waypoint_index)
            current_initial_position_in_x = current_target_position[0]
            current_initial_position_in_y = current_target_position[1]
            current_initial_position_in_z = current_target_position[2]
            current_time_since_step_Start = (time.time() - time_start) / number_of_simulation_steps
            print("Current time since start : ", current_time_since_step_Start)

            constant_for_a1 = -1/(32 * (time_to_travel ** 4))
            a1_x = constant_for_a1 * displacement_in_x
            a1_y = constant_for_a1 * displacement_in_y
            a1_z = constant_for_a1 * displacement_in_z

            a2_x = -time_to_travel * a1_x
            a2_y = -time_to_travel * a1_y
            a2_z = -time_to_travel * a1_z
            x_at_half_tf = current_initial_position_in_x + (a1_x/12) * ((time_to_travel/2) ** 4) + (a2_x / 6) * ((time_to_travel/2) ** 3)
            y_at_half_tf = current_initial_position_in_y + (a1_y/12) * ((time_to_travel/2) ** 4) + (a2_y / 6) * ((time_to_travel/2) ** 3)
            z_at_half_tf = current_initial_position_in_z + (a1_z/12) * ((time_to_travel/2) ** 4) + (a2_z / 6) * ((time_to_travel/2) ** 3)

            v_max_x = (a1_x / 3) * ((time_to_travel/2) ** 3) + (a2_x / 2) * ((time_to_travel) ** 2)
            v_max_y = (a1_y / 3) * ((time_to_travel/2) ** 3) + (a2_y / 2) * ((time_to_travel) ** 2)
            v_max_z = (a1_z / 3) * ((time_to_travel/2) ** 3) + (a2_z / 2) * ((time_to_travel) ** 2)
            if(current_time_since_step_Start >0 and current_time_since_step_Start < (time_to_travel/2)) : 
                desired_position_in_x = current_initial_position_in_x + (a1_x/12) * ((current_time_since_step_Start) ** 4) + (a2_x / 6) * ((current_time_since_step_Start) ** 3)
                desired_position_in_y = current_initial_position_in_y + (a1_y/12) * ((current_time_since_step_Start) ** 4) + (a2_y / 6) * ((current_time_since_step_Start) ** 3)
                desired_position_in_z = current_initial_position_in_z + (a1_z/12) * ((current_time_since_step_Start) ** 4) + (a2_z / 6) * ((current_time_since_step_Start) ** 3)
                print("Desired position in first half : ", desired_position_in_x, desired_position_in_y, desired_position_in_z)
                desired_velocity_in_x = (a1_x/3) * ((current_time_since_step_Start) ** 3) + (a2_x/2) * ((current_time_since_step_Start) ** 2)
                desired_velocity_in_y = (a1_y/3) * ((current_time_since_step_Start) ** 3) + (a2_y/2) * ((current_time_since_step_Start) ** 2)
                desired_velocity_in_z = (a1_z/3) * ((current_time_since_step_Start) ** 3) + (a2_z/2) * ((current_time_since_step_Start) ** 2)
                print("Desired velocity in first half : ", desired_velocity_in_x, desired_velocity_in_y, desired_velocity_in_z)

            if(current_time_since_step_Start > (time_to_travel/2) and current_time_since_step_Start < time_to_travel) : 
                constant_x_for_b = v_max_x / (2 * ((time_to_travel/2)**3))
                b1_x = - constant_x_for_b
                b2_x = time_to_travel * constant_x_for_b

                constant_y_for_b = v_max_y / (2 * ((time_to_travel/2)**3))
                b1_y = - constant_y_for_b
                b2_y = time_to_travel * constant_y_for_b

                constant_z_for_b = v_max_z / (2 * ((time_to_travel/2)**3))
                b1_z = - constant_z_for_b
                b2_z = time_to_travel * constant_z_for_b

                t_d = current_time_since_step_Start - (time_to_travel/2)
                desired_position_in_x = x_at_half_tf + (b1_x/12) * ((t_d) ** 4) + (b2_x / 6) * ((t_d) ** 3)
                desired_position_in_y = y_at_half_tf + (b1_y/12) * ((t_d) ** 4) + (b2_y / 6) * ((t_d) ** 3)
                desired_position_in_z = z_at_half_tf + (b1_z/12) * ((t_d) ** 4) + (b2_z / 6) * ((t_d) ** 3)
                print("Desired position in 2nd half : ", desired_position_in_x, desired_position_in_y, desired_position_in_z)

                desired_velocity_in_x = (b1_x/3) * ((t_d) ** 3) + (b2_x/2) * ((t_d) ** 2)
                desired_velocity_in_y = (b1_y/3) * ((t_d) ** 3) + (b2_y/2) * ((t_d) ** 2)
                desired_velocity_in_z = (b1_z/3) * ((t_d) ** 3) + (b2_z/2) * ((t_d) ** 2)
                print("Desired velocity in 2nd half : ", desired_velocity_in_x, desired_velocity_in_y, desired_velocity_in_z)

            #desired_position_in_x = ((current_time_since_step_Start**2)*(3-2*current_time_since_step_Start)) * displacement_in_x
            #desired_position_in_y = ((current_time_since_step_Start**2)*(3-2*current_time_since_step_Start)) * displacement_in_y
            #desired_position_in_z = ((current_time_since_step_Start**2)*(3-2*current_time_since_step_Start)) * displacement_in_z

            position_desired = np.array([desired_position_in_x, desired_position_in_y, desired_position_in_z])
            print("position_desired : ", position_desired)
            #velocity_desired = np.array([displacement_in_x, displacement_in_y, displacement_in_z])
            velocity_desired = np.array([desired_velocity_in_x, desired_velocity_in_y, desired_velocity_in_z])

            # Get the Jacobian at the end-effector.
            mujoco.mj_jacSite(model, data, jac[ : 3],jac[3 : ], site_id)
            J = jac[:, dof_ids]

            # Compute the position and orientation errors.
            dx = position_desired - data.site(site_id).xpos
            mujoco.mju_mat2Quat(site_quat, data.site(site_id).xmat)
            mujoco.mju_negQuat(site_quat_conj, site_quat)
            mujoco.mju_mulQuat(error_quat, site_quat_conj, data.mocap_quat[mocap_id])
            mujoco.mju_quat2Vel(twist[3:], error_quat, 1.0)

            # P control.
            twist[:3] = Kpos * dx / dt

            # Desired twist in end-effector frame.
            vel_des = np.zeros(7)
            vel_des = J * data.qvel[dof_ids]

            # Add nullspace velocity to ensure the arm stays close to its initial configuration.
            qerr = data.qpos[dof_ids] - q0[ : 7]
            vel_des[dof_ids] -= (eye - J.T @ np.linalg.solve(J @ J.T + diag[:6,:6], J[:6,:6])) @ (Kn * qerr)

            # Apply maximum angular velocity constraint.
            for j in dof_ids:
                vel_des[j] = np.clip(vel_des[j], -max_angvel, max_angvel)

            # Convert desired velocity to desired joint positions.
            qpos_err = data.qpos[dof_ids] - (data.qpos[dof_ids] + vel_des[dof_ids] * integration_dt)

            # PD control to compute joint torques
            qvel_err = data.qvel[dof_ids] - vel_des[dof_ids]
            desired_torques = Kp * qpos_err + Kd * qvel_err

            # Set joint torques as the control input
            data.ctrl[actuator_ids] = desired_torques

            velocity_in_x.append(data.qvel[0])
            velocity_in_y.append(data.qvel[1])
            velocity_in_z.append(data.qvel[2])
            time_axis_index.append(time.time() - time_start)
            # Step the simulation.
            mujoco.mj_step(model, data)

            # Update the scene in the viewer.
            viewer.sync()
            index_time += 1
            if index_time >= number_of_simulation_steps:
                index_time = 0
                time_start = time.time()

    #plotting graphs
    plt.plot(time_axis_index, velocity_in_x, label="Velocity in X")
    plt.plot(time_axis_index, velocity_in_y, label="Velocity in Y")
    plt.plot(time_axis_index, velocity_in_z, label="Velocity in Z")
    plt.xlabel("Time (s)")
    plt.ylabel("Joint Velocity")
    plt.legend()
    plt.title("Joint Velocities Over Time")
    plt.grid()
    plt.show()

if __name__ == "__main__":
    main()
