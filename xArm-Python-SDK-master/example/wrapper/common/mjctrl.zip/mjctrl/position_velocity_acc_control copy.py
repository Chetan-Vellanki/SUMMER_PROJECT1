import mujoco
import mujoco.viewer
import numpy as np
import time
import threading
import matplotlib.pyplot as plt

# Integration timestep in seconds. This corresponds to the amount of time the joint
# velocities will be integrated for to obtain the desired joint positions.
integration_dt: float = 0.1

# Damping ratio for both Cartesian and joint impedance control.
damping_ratio = 1.0



# Damping term for the pseudoinverse. This is used to prevent joint velocities from
# becoming too large when the Jacobian is close to singular.
damping: float = 1e-4

# Gains for the twist computation. These should be between 0 and 1. 0 means no
# movement, 1 means move the end-effector to the target in one integration step.
Kpos: float = 0.95
Kori: float = 0.95

# Whether to enable gravity compensation.
gravity_compensation: bool = True

# Simulation timestep in seconds.
dt: float = 0.002
time_to_achieve_desired_position =integration_dt

# Nullspace P gain.
Kn = np.asarray([10.0, 10.0, 10.0, 10.0, 5.0, 5.0, 5.0])

# Maximum allowable joint velocity in rad/s.
max_angvel = 0.785

# PD control gains
Kp = 250  # Proportional gain
Kd = 70 # Derivative gain
Ki = 0.01
# Target positions array.
target_positions = [np.array([0.5, 0, 0.32])]
number_of_simulation_steps = integration_dt / dt

def user_input_thread():
    global target_positions
    x = float(input("Enter target x position: "))
    y = float(input("Enter target y position: "))
    z = float(input("Enter target z position: "))
    new_position = np.array([x, y, z])
    target_positions.append(new_position)
    # print(f"New target position {new_position} added.")
    # except ValueError:
    #     print("Invalid input. Please enter numerical values for x, y, and z.")

def main() -> None:
    assert mujoco.__version__ >= "3.1.0", "Please upgrade to mujoco 3.1.0 or later."

    # Load the model and data.
    model = mujoco.MjModel.from_xml_path("ufactory_xarm7/scene_strike_act.xml")
    data = mujoco.MjData(model)

    # Enable gravity compensation. Set to 0.0 to disable.
    model.body_gravcomp[:17] = float(gravity_compensation)
    model.opt.timestep = dt

    # End-effector site we wish to control.
    site_name = "link_tcp"
    site_id = model.site(site_name).id
    # print("site_id: ", site_id)

    # Get the dof and actuator ids for the joints we wish to control. These are copied
    # from the XML file. Feel free to comment out some joints to see the effect on
    # the controller.
    joint_names = [
        "joint1",
        "joint2",
        "joint3",
        "joint4",
        "joint5",
        "joint6",
        "joint7",
    ]
    dof_ids = np.array([model.joint(name).id for name in joint_names])
    actuator_ids = np.array([model.actuator(name).id for name in joint_names])
    # print("dof_ids: ", dof_ids)

    # Initial joint configuration saved as a keyframe in the XML file.
    key_name = "home"
    key_id = model.key(key_name).id
    q0 = model.key(key_name).qpos
    #only till joints
    q01 = q0[:7]
    # print("keyid:", key_id)
    # print("qo:", q0)

    # Mocap body we will control with our mouse.
    mocap_name = "target"
    mocap_id = model.body(mocap_name).mocapid[0]
    
    current_waypoint_index = 0

    

    # Pre-allocate numpy arrays.
    jac = np.zeros((6, model.nv))
    diag = damping * np.eye(7)
    eye = np.eye(7)
    twist = np.zeros(6)
    site_quat = np.zeros(4)
    site_quat_conj = np.zeros(4)
    error_quat = np.zeros(4)
    Kvel= 0.5
    M_inv = np.array((model.nv, model.nv))
    # target_velocity = np.array([2.0, 0.0, 0.0])

    # Start the user input thread.
    velocity_in_x = []
    velocity_in_y = []
    velocity_in_z = []
    time_axis_index = []
    time_start = time.time()
    previous_time = time.time()
    previous_error = np.zeros(3)
    position_error_in_x = 0
    position_error_in_y = 0
    position_error_in_z = 0
    desired_position_in_x = 0
    desired_position_in_y = 0
    desired_position_in_z = 0
    desired_velocity_in_x = 0
    desired_velocity_in_y = 0
    desired_velocity_in_z = 0
    desired_acc_in_x = 0
    desired_acc_in_y = 0
    desired_acc_in_z = 0
    desired_velocity = np.zeros(3)
    desired_position = np.zeros(3)

    initial_angle = np.array([0,-.247, 0 ,.909 ,0 ,1.15644 ,0 ,0])
    

    with mujoco.viewer.launch_passive(
        model=model,
        data=data,
        show_left_ui=False,
        show_right_ui=False,
    ) as viewer:
        time_start = time.time()
        # Reset the simulation.
        mujoco.mj_resetDataKeyframe(model, data, key_id)

        

        # Reset the free camera.
        mujoco.mjv_defaultFreeCamera(model, viewer.cam)

        # Enable site frame visualization.
        viewer.opt.frame = mujoco.mjtFrame.mjFRAME_SITE
        q11=[]
        
        index_time = 0
        
        # initial_position = np.array([0.4,0,0.3])
        time.sleep(0.01)
        initial_position = data.site(site_id).xpos.copy()
        index_for_loop = 0
        START_TIME = time.time()
        while viewer.is_running():
            
            step_start = time.time()
            # print("step_dart_time = ",step_start)
            # initial_position = data.site(site_id).xpos.copy()
            

            # Spatial velocity (aka twist).
            current_waypoint = target_positions[current_waypoint_index]
            dx = current_waypoint - data.site(site_id).xpos
            
            # print("dx : ", np.linalg.norm(dx))
            # print("Distance to the target position : ", np.linalg.norm(dx))
            if np.linalg.norm(dx) < 0.02:  # Tolerance of 1 cm to consider as reached
                user_input_thread()
                time_start = time.time()
                # time_start = time.time()
                current_waypoint_index += 1
                if current_waypoint_index >= len(target_positions):
                    current_waypoint_index = 0 
            
            # print("Current_time = ", time.time() - step_start)
            if(current_waypoint_index == 0) : 
                current_target_position = np.array([0.3,0,0.5])
                print("Initial position : ", initial_position)
            if(current_waypoint_index >= 1) :
                current_target_position = target_positions[current_waypoint_index - 1]
            new_target_position = target_positions[current_waypoint_index]
            delta_position_vector = new_target_position - current_target_position
            distance_to_travel = np.linalg.norm(new_target_position - current_target_position)
            displacement_in_x = delta_position_vector[0]
            displacement_in_y = delta_position_vector[1]
            displacement_in_z = delta_position_vector[2]
            time_to_travel = integration_dt
            # I AM TAKING AS MAXIMUM ACCELERATION IS PROPORTIONAL TO 
            # THE MAX DISTANCE BETWEEN TWO TARGET POSITIONS IN THE RESPECTIVE DIRECTION
            # print("waypoint index : ", current_waypoint_index)
            current_initial_position_in_x = current_target_position[0]
            current_initial_position_in_y = current_target_position[1]
            current_initial_position_in_z = current_target_position[2]
            current_time_since_step_Start = index_for_loop * dt
            # print("Current time since start : ", current_time_since_step_Start)

            # Calculating the terms a1 and a2 as per the designed control trajectory
            constant_for_a1 = -1/(32 * (time_to_travel ** 4))
            a1_x = constant_for_a1 * displacement_in_x
            a1_y = constant_for_a1 * displacement_in_y
            a1_z = constant_for_a1 * displacement_in_z

            a2_x = -time_to_travel * a1_x
            a2_y = -time_to_travel * a1_y
            a2_z = -time_to_travel * a1_z
            x_at_half_tf = current_initial_position_in_x + (a1_x/12) * ((time_to_travel/2) ** 4) + (a2_x / 6) * ((time_to_travel/2) ** 3)
            y_at_half_tf = current_initial_position_in_y + (a1_y/12) * ((time_to_travel/2) ** 4) + (a2_y / 6) * ((time_to_travel/2) ** 3)
            z_at_half_tf = current_initial_position_in_z + (a1_z/12) * ((time_to_travel/2) ** 4) + (a2_z / 6) * ((time_to_travel/2) ** 3)

            v_max_x = (a1_x / 3) * ((time_to_travel/2) ** 3) + (a2_x / 2) * ((time_to_travel) ** 2)
            v_max_y = (a1_y / 3) * ((time_to_travel/2) ** 3) + (a2_y / 2) * ((time_to_travel) ** 2)
            v_max_z = (a1_z / 3) * ((time_to_travel/2) ** 3) + (a2_z / 2) * ((time_to_travel) ** 2)
            if(current_time_since_step_Start >=0 and current_time_since_step_Start <= (time_to_travel/2)) : 
                print("FLAG = 1")
                desired_position_in_x= current_initial_position_in_x + (a1_x/12) * (current_time_since_step_Start ** 4) + (a2_x / 6) * (current_time_since_step_Start ** 3)
                desired_position_in_y = current_initial_position_in_x + (a1_y/12) * (current_time_since_step_Start ** 4) + (a2_y / 6) * (current_time_since_step_Start ** 3)
                desired_position_in_z = current_initial_position_in_x + (a1_z/12) * (current_time_since_step_Start ** 4) + (a2_z / 6) * (current_time_since_step_Start ** 3)

                desired_velocity_in_x = (a1_x / 3) * (current_time_since_step_Start ** 3) + (a2_x / 2) * (current_time_since_step_Start ** 2)
                desired_velocity_in_y = (a1_y / 3) * (current_time_since_step_Start ** 3) + (a2_y / 2) * (current_time_since_step_Start ** 2)
                desired_velocity_in_z = (a1_z / 3) * (current_time_since_step_Start ** 3) + (a2_z / 2) * (current_time_since_step_Start ** 2)
                desired_velocity = np.array([desired_velocity_in_x,desired_velocity_in_y,desired_velocity_in_z])
                desired_acc_in_x = a1_x * (current_time_since_step_Start ** 2) + a2_x * current_time_since_step_Start
                desired_acc_in_y = a1_y * (current_time_since_step_Start ** 2) + a2_y * current_time_since_step_Start
                desired_acc_in_z = a1_z * (current_time_since_step_Start ** 2) + a2_z * current_time_since_step_Start
            
            
            elif(current_time_since_step_Start >= (time_to_travel/2) and current_time_since_step_Start <= (time_to_travel)) :
                desired_position_in_x = 2 * x_at_half_tf - current_initial_position_in_x + 2 * v_max_x * (current_time_since_step_Start - (time_to_travel/2)) - ((a1_x/12) * (current_time_since_step_Start ** 4) + (a2_x / 6) * (current_time_since_step_Start ** 3)) 
                desired_position_in_y = 2 * y_at_half_tf - current_initial_position_in_y + 2 * v_max_y * (current_time_since_step_Start - (time_to_travel/2)) - ((a1_y/12) * (current_time_since_step_Start ** 4) + (a2_y / 6) * (current_time_since_step_Start ** 3))
                desired_position_in_z = 2 * z_at_half_tf - current_initial_position_in_z + 2 * v_max_z * (current_time_since_step_Start - (time_to_travel/2)) - ((a1_z/12) * (current_time_since_step_Start ** 4) + (a2_z / 6) * (current_time_since_step_Start ** 3))

                desired_velocity_in_x = 2 * v_max_x -  ((a1_x / 3) * (current_time_since_step_Start ** 3) + (a2_x / 2) * (current_time_since_step_Start ** 2))
                desired_velocity_in_y = 2 * v_max_y - ((a1_y / 3) * (current_time_since_step_Start ** 3) + (a2_y / 2) * (current_time_since_step_Start ** 2))
                desired_velocity_in_z = 2 * v_max_z - ((a1_z / 3) * (current_time_since_step_Start ** 3) + (a2_z / 2) * (current_time_since_step_Start ** 2))

                desired_acc_in_x = -1 * (a1_x * (current_time_since_step_Start ** 2) + a2_x * current_time_since_step_Start)
                desired_acc_in_y = -1 * (a1_y * (current_time_since_step_Start ** 2) + a2_y * current_time_since_step_Start)
                desired_acc_in_z = -1 * (a1_z * (current_time_since_step_Start ** 2) + a2_z * current_time_since_step_Start)

            
            position_error_in_x = desired_position_in_x - data.site(site_id).xpos[0]
            position_error_in_y = desired_position_in_y - data.site(site_id).xpos[1]
            position_error_in_z = desired_position_in_z - data.site(site_id).xpos[2]
            desired_position = np.array([desired_position_in_x, desired_position_in_y, desired_position_in_z])
            position_error = np.array([position_error_in_x,position_error_in_y, position_error_in_z])

            # if(current_time_since_step_Start >= integration_dt) : 
            #     index_for_loop = 0

            print("DESIRED POSITION : ", desired_position)
            current_joint_velocities = data.qvel[dof_ids]
            # print("Joint_Velocities dimension :  ", current_joint_velocities.shape)
            current_joint_accelerations = data.qacc[dof_ids]

            mujoco.mj_jacSite(model, data, jac[:3], jac[3:], site_id)
            jac1 = jac[:,:7]
            # print("Jacobian dimensions : ", jac.shape)
            current_end_eff_velocity = jac1[ : 3] @ current_joint_velocities
            
            # currently ignoring the derivative the derivative of the jacobian assuming 
            # the orientation does not change much as it is trajectory based control
            current_end_eff_acc = jac1[ : 3] @ current_joint_accelerations

            velocity_error_in_x = desired_velocity_in_x - current_end_eff_velocity[0]
            velocity_error_in_y = desired_velocity_in_y - current_end_eff_velocity[1]
            velocity_error_in_z = desired_velocity_in_z - current_end_eff_velocity[2] 
            velocity_error = np.array([velocity_error_in_x,velocity_error_in_y,velocity_error_in_z])
            acceleraton_error_in_x = desired_acc_in_x - current_end_eff_acc[0]
            acceleraton_error_in_y = desired_acc_in_y - current_end_eff_acc[1]
            acceleraton_error_in_z = desired_acc_in_z - current_end_eff_acc[2]
            acceleration_error = np.array([acceleraton_error_in_x,acceleraton_error_in_y,acceleraton_error_in_z])

            Control_Force_at_end_Effector = Kp * position_error + Kd * velocity_error

            Joint_Torques = jac1[ : 3].T @ Control_Force_at_end_Effector
            # Joint_Torques = np.array([0,0,0,0,0,0.5,0]) * 10 
            # current_time = time.time()
            # print(current_time_since_step_Start)
            # dt_1 = current_time - previous_time
            # derivative = (error - previous_error) / dt_1
            # target_velocity = Kp * error + Kd * derivative
            # previous_error = error
            # previous_time = current_time

            twist[:3] = Kpos * desired_velocity / integration_dt
            mujoco.mju_mat2Quat(site_quat, data.site(site_id).xmat)
            mujoco.mju_negQuat(site_quat_conj, site_quat)
            mujoco.mju_mulQuat(error_quat, data.mocap_quat[mocap_id], site_quat_conj)
            mujoco.mju_quat2Vel(twist[3:], error_quat, 1.0)
            twist[3:] *= Kori / integration_dt


            # Jacobian.
            mujoco.mj_jacSite(model, data, jac[:3], jac[3:], site_id)

            # Damped least squares.
            jac1 = jac[:,:7]
            dq = np.linalg.solve(jac1.T @ jac1 + diag, jac1.T @ twist)
            
            dq += (eye - np.linalg.pinv(jac1) @ jac1) @ (Kn * (q0[:7] - data.qpos[dof_ids]))





            ## adding gravity compensation
            if gravity_compensation:
                Joint_Torques += data.qfrc_bias[dof_ids]
            # Clamp maximum joint velocity.
            dq_abs_max = np.abs(dq).max()
            if dq_abs_max > max_angvel:
                dq *= max_angvel / dq_abs_max

            # Integrate joint velocities to obtain joint positions.
            q = data.qpos.copy()  # Note the copy here is important.
            dq1 = np.append(dq, np.zeros(12))
            mujoco.mj_integratePos(model, q, dq1, integration_dt)
            # np.clip(q[:14], *model.jnt_range.T, out=q[:14])
            # print("Actuator Control Range  : ",model.actuator_ctrlrange.shape)
            np.clip(Joint_Torques, *model.actuator_ctrlrange[:7].T, out=Joint_Torques)
            # Set the control signal and step the simulation.
            data.ctrl[7] = 248
            #position
            #data.ctrl[actuator_ids] = q[dof_ids]
            #velocity

            # print("Join Torques : ", Joint_Torques)
            data.ctrl[actuator_ids] = Joint_Torques[dof_ids]  
            print("Current position :", data.site(site_id).xpos)
            mujoco.mj_step(model, data)

            dx_waypoints = desired_position - data.site(site_id).xpos
            if(np.linalg.norm(dx_waypoints) < 0.01) :
                index_for_loop += 1
             


            viewer.sync()


            time_until_next_step = dt - (time.time() - step_start)
            if time_until_next_step > 0:
                time.sleep(time_until_next_step)
                # print("SLEEP FLG is TRUE")

            # if time_until_next_step < 0 : 
            #     print("NUMBER OF TIMES LOOP EXECUTING : ", index_for_loop)
            #     print("TIME TAKEN : ", time.time() - START_TIME)

            # if(time.time() - START_TIME > integration_dt) : 
            #     print("loop runs : ", index_for_loop)
            #     break

            # threading.Thread(target=user_input_thread, daemon=True).start()


if __name__ == "__main__":
    main()
