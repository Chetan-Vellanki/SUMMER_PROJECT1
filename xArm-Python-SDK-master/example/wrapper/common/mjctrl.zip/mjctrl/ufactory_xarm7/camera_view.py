import mujoco_py
import numpy as np
import cv2

# Load the model
model = mujoco_py.load_model_from_path('path_to_your_model.xml')
sim = mujoco_py.MjSim(model)
viewer = mujoco_py.MjRenderContextOffscreen(sim, 0)

# Function to capture an image from the simulated camera
def capture_image(sim, viewer):
    viewer.render()
    width, height = viewer.viewport.width, viewer.viewport.height
    image = viewer.read_pixels(width, height, depth=False)
    return image

# Continuous simulation and capturing images
while True:
    sim.step()
    image = capture_image(sim, viewer)

    # Convert the image to OpenCV format
    image = np.flipud(image)  # Flip the image vertically
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

    # Display the image
    cv2.imshow('Simulated Camera Image', image)

    # Break the loop if 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Cleanup
cv2.destroyAllWindows()