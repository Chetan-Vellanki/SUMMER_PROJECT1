import mujoco
import mujoco.viewer
import numpy as np
import time
import matplotlib.pyplot as plt
import scipy.interpolate 

# Cartesian impedance control gains.
impedance_pos = np.asarray([4000 , 4000.0, 4000.0])  # [N/m]
impedance_ori = np.asarray([50.0, 50.0, 50.0])  # [Nm/rad]
Ki = np.array([0.002,0.002,0.002,0.002,0.002,0.002])

# Joint impedance control gains.0
Kp_null = np.asarray([75.0, 75.0, 50.0, 50.0, 70.0, 40.0, 50.0])
# Damping ratio for both Cartesian and joint impedance control.
damping_ratio = 2

# Gains for the twist computation. These should be between 0 and 1. 0 means no
# movement, 1 means move the end-effector to the target in one integration step.
Kpos: float = 0.95

# Gain for the orientation component of the twist computation. This should be
# between 0 and 1. 0 means no movement, 1 means move the end-effector to the target
# orientation in one integration step.
Kori: float = 0.95

# Integration timestep in seconds.
integration_dt: float = 0.4

# Whether to enable gravity compensation.
gravity_compensation: bool = True

# Simulation timestep in seconds.
dt: float = 0.002


## defining a function which which calculates the samples for the trajectory
def trajectory(initial_pos , final_pos, time_to_travel) :
    a1 =  (-32) * (final_pos - initial_pos) * (1/ (time_to_travel ** 4))
    a2 = -1 * a1 * time_to_travel
    number_of_waypoints = np.linalg.norm(final_pos - initial_pos) * 50 / 2 
    number_of_waypoints = int(number_of_waypoints)
    print("NO OF WAYPOINTS : ", number_of_waypoints)
    captured_waypoints = []
    velocity_waypoints = []
    acceleration_waypoints = []
    waypoints_index = 0
    while (waypoints_index <= number_of_waypoints) :
        time = (time_to_travel * waypoints_index) / number_of_waypoints
        if( time >=0 and time <= (time_to_travel / 2)) : 
            position = initial_pos + (a1/12) * (time ** 4) + (a2 / 6) * (time ** 3)
            captured_waypoints.append(np.array(position)) 
            velocity = (a1/3) * (time ** 3) + (a2/2) * (time ** 2)
            velocity_waypoints.append(np.array(velocity))
            acceleration = a1 * (time ** 2) + a2 * (time)
            acceleration_waypoints.append(np.array(acceleration))
        half_time = time_to_travel / 2
        vmax = (a1/3) * (half_time ** 3) + (a2/2) * ( half_time ** 2)
        x_t_half = initial_pos + (a1/12) * (half_time ** 4) + (a2 / 6) * (half_time ** 3)
        if( time > time_to_travel/2  and time <= time_to_travel) : 
            position = 2 * x_t_half - initial_pos + 2 * vmax * (time - half_time) - ((a1/12) * (time ** 4) + (a2 / 6) * (time ** 3))
            captured_waypoints.append(np.array(position))
            velocity = 2 * vmax - ((a1/3) * (time ** 3) + (a2/2) * (time ** 2))
            velocity_waypoints.append(np.array(velocity))
            acceleration = -1 * (a1 * (time ** 2) + a2 * (time))
            acceleration_waypoints.append(np.array(acceleration))
        waypoints_index = waypoints_index + 1
    return captured_waypoints, velocity_waypoints, acceleration_waypoints



def interpolate_trajectory(waypoints, velocities, accelerations, num_samples):
    times = np.linspace(0, 1, len(waypoints))
    interp_pos = scipy.interpolate.interp1d(times, waypoints, kind='cubic', axis=0)
    interp_vel = scipy.interpolate.interp1d(times, velocities, kind='cubic', axis=0)
    interp_acc = scipy.interpolate.interp1d(times, accelerations, kind='cubic', axis=0)
    sample_times = np.linspace(0, 1, num_samples)
    interp_positions = interp_pos(sample_times)
    interp_velocities = interp_vel(sample_times)
    interp_accelerations = interp_acc(sample_times)
    return interp_positions, interp_velocities, interp_accelerations


def main() -> None:
    assert mujoco.__version__ >= "3.1.0", "Please upgrade to mujoco 3.1.0 or later."

    # Load the model and data.
    model = mujoco.MjModel.from_xml_path("ufactory_xarm7/scene_strike_act.xml")
    data = mujoco.MjData(model)

    model.opt.timestep = dt

    # Compute damping and stiffness matrices.
    damping_pos = damping_ratio * 2 * np.sqrt(impedance_pos)
    damping_ori = damping_ratio * 2 * np.sqrt(impedance_ori)
    Kp = np.concatenate([impedance_pos, impedance_ori], axis=0)
    Kd = np.concatenate([damping_pos, damping_ori], axis=0)
    Kd_null = damping_ratio * 2 * np.sqrt(Kp_null)



    # End-effector site we wish to control.
    site_name = "link_tcp"
    site_id = model.site(site_name).id

    # Get the dof and actuator ids for the joints we wish to control. These are copied
    # from the XML file. Feel free to comment out some joints to see the effect on
    # the controller.
    joint_names = [
        "joint1",
        "joint2",
        "joint3",
        "joint4",
        "joint5",
        "joint6",
        "joint7",
    ]
    dof_ids = np.array([model.joint(name).id for name in joint_names])
    actuator_ids = np.array([model.actuator(name).id for name in joint_names])

    # Initial joint configuration saved as a keyframe in the XML file.
    key_name = "home"
    key_id = model.key(key_name).id
    q0 = model.key(key_name).qpos 

    # Mocap body we will control with our mouse.
    mocap_name = "target"
    mocap_id = model.body(mocap_name).mocapid[0]

    # object_name = "object"
    # object_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, object_name)

    waypoints = []
    current_waypoint_index = 0
    

    object_name = "object"
    object_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, object_name)
    # Pre-allocate numpy arrays.
    jac = np.zeros((6, model.nv))
    twist = np.zeros(6)
    site_quat = np.zeros(4)
    site_quat_conj = np.zeros(4)
    object_quat = np.zeros(4)
    error_quat = np.zeros(4)
    M_inv = np.zeros((model.nv, model.nv))
    Mx = np.zeros((6, 6))
    h = np.zeros(model.nv)
    # print("DOFids : ", dof_ids.shape)
    previous_time = time.time()
    jac_prev = np.zeros((6, model.nv))
    error_jac = np.zeros((6, model.nv))
    jac_dot = np.zeros((6, model.nv))
    mujoco.mj_jacSite(model, data, jac_prev[:3], jac_prev[3:], site_id)
    flag_for_index_0 = 1
    get_into_waypoints_update = 1

    error_in_twist = 0
    initial_position = np.zeros(3)
    final_position = np.zeros(3)
    desired_velocity = np.zeros(3)
    # desired_acceleration = np.array(6)
    dx = np.zeros(3)

    time_data = []
    # waypoint_data = [wp[0] for wp in waypoints]
    position_data_in_x = []
    position_data_in_y = []
    position_data_in_z = []
    velocity_data_in_x = []
    velocity_data_in_y = []
    velocity_data_in_z = []
    distance_data = []
    target_data_in_x = []
    target_data_in_y = []
    target_data_in_z = []

    target_vel_in_x = []
    target_vel_in_y = []
    target_vel_in_z = []
    dx_data = []
    end_effector_velocity = np.zeros(6)
    time_start = time.time()
    num_samples = 1350

    with mujoco.viewer.launch_passive(
        model=model,
        data=data,
        show_left_ui=False,
        show_right_ui=False,
    ) as viewer:
        # Reset the simulation.
        # mujoco.mj_resetDataKeyframe(model, data, key_id)

        # Reset the free camera.
        mujoco.mjv_defaultFreeCamera(model, viewer.cam)

        # Enable site frame visualization.
        viewer.opt.frame = mujoco.mjtFrame.mjFRAME_SITE
        trajectory_index = 1
        while viewer.is_running():
            step_start = time.time()

            object_pos = data.body(object_id).xpos
            object_orientation = data.body(object_id).xmat

            # object_orientation = object_orientation * -1 
            # mujoco.mju_mat2Quat(object_quat, object_orientation)
            
            # object_quat = object_quat * -1
            object_pos[0] = object_pos[0] - 0.03
            object_pos[2] = object_pos[2] + 0.08
            # print("SITE_POS : ", data.site(site_id).xpos)


            # take the initial and final positions for the trajectory 
            
            if(trajectory_index == 1) :
                initial_position = data.site(site_id).xpos
                final_position = data.body(object_id).xpos
                print("INITIAL POSITION : ", initial_position)
                print("FINAL POSITION : ", final_position)
                trajectory_index = 0
                time_to_travel =  3
            
                captured_waypoints , velocity_waypoints, acceleration_waypoints = trajectory(initial_position, final_position , time_to_travel)
                  # You can adjust the number of samples as needed
                interp_positions, interp_velocities, interp_accelerations = interpolate_trajectory(captured_waypoints, velocity_waypoints, acceleration_waypoints, num_samples)
                # print("Captured accelerations : ", acceleration_waypoints)
                # print("Captured_waypoints : ", captured_waypoints)
            


            # if(current_waypoint_index == 0 and flag_for_index_0 == 1) :
            #     # print("ENTERED THE IF STATEMENT 1")
            #     flag_for_index_0 = 0 
            #     waypoints.append(captured_waypoints[current_waypoint_index])
            #     print("Waypoints : ", waypoints)

            current_position = interp_positions[current_waypoint_index]
            current_velocity = interp_velocities[current_waypoint_index]
            current_acceleration = interp_accelerations[current_waypoint_index]
            
            # current_waypoint = captured_waypoints[current_waypoint_index]
            # print("XJSDHFJLH : ", captured_waypoints[0])
            # print("Current waypoint : ", current_waypoint)
            dx = current_position - data.site(site_id).xpos
            # position_in_x = data.site(site_id).xpos[0]
        
            # if(current_waypoint_index == (len(waypoints) - 1)) : 
            #     Tolerance = 0.02
            #     print("flag 1")
            #     if(np.linalg.norm(dx) == Tolerance) : 
            #         current_waypoint_index = current_waypoint_index + 1
            #         print("flag 2")
                    # if current_waypoint_index >= len(waypoints):
                    #     current_waypoint_index = len(waypoints - 1)

            # if  current_waypoint_index <= len(captured_waypoints) - 1 :  # Tolerance of 1 cm to consider as reached
            Tolerance = 0.06
                # print("Flag = 1")
                # print("Distance to waypoint : ", np.linalg.norm(dx))
            time_now = time.time()
            
            
            # if(np.linalg.norm(object_pos[0] - data.site(site_id).xpos[0]) <= Tolerance) :   # and np.linalg.norm(end_effector_velocity - desired_velocity[current_waypoint_index]) <= Tolerance) : 
            #             # waypoints.append(captured_waypoints[current_waypoint_index]
            #     current_waypoint_index = 0
            #     # trajectory_index = 1
            #     print("FLAG = 1")
            #     print("WAYPOINT INDEX : ", current_waypoint_index)
            #     # current_waypoint_index += 1
            #     print("Current position : " ,data.site(site_id).xpos)
            #     print("Next estimated position : ", captured_waypoints[current_waypoint_index])
            
            # print("Final Position : ", object_pos)
            # print("End effector position : ", data.site(site_id).xpos)           

            # if np.linalg.norm(data.site(site_id).xpos[0] > 0.65) :
            #     get_into_waypoints_update = 0
            #     waypoints.append(waypoints[0])

            # if current_waypoint_index >= len(waypoints):
            #     # time.sleep(0.0001)
            #     current_waypoint_index = len(waypoints) - 1
            # print("Object Position : ", object_pos)
            # Spatial velocity (aka twist).
            # dx = [current_waypoint_index] - data.site(site_id).xpos
            twist[:3] = Kpos * dx / integration_dt
            mujoco.mju_mat2Quat(site_quat, data.site(site_id).xmat)
            # mujoco.mju_mat2Quat(object_quat, data.body(object_id).xmat)
            object_quat = data.body(object_id).xquat
            mujoco.mju_negQuat(site_quat_conj, site_quat)
            mujoco.mju_mulQuat(object_quat,object_quat, site_quat_conj)
            mujoco.mju_mulQuat(error_quat, object_quat, site_quat_conj)
            # mujoco.mju_mulQuat(error_quat, data.mocap_quat[mocap_id], site_quat_conj)
            mujoco.mju_quat2Vel(twist[3:], error_quat, 1.0)
            twist[3:] *= Kori / integration_dt
            error_in_twist = error_in_twist + twist
            
            # Jacobian.
            mujoco.mj_jacSite(model, data, jac[:3], jac[3:], site_id)
            error_jac = jac - jac_prev
            current_time = time.time()
            error_time  = current_time - previous_time
            jac_dot = error_jac / error_time
            previous_time = current_time
            jac_prev = jac
            
            # print("JAC : ", jac.shape)
            jac1 = jac[:,[0,1,2,3,4,5,6]]
            
            # print("Dimention of matrix :" , jac1.shape)

            # Compute the task-space inertia matrix.
            mujoco.mj_solveM(model, data, M_inv, np.eye(model.nv))
            # print("dimention of M_inv : ", M_inv.shape)
            Mx_inv = jac1 @ M_inv[:7,:7] @ jac1.T
            # print("dimention of Mx_inv : ", Mx_inv.shape)
            if abs(np.linalg.det(Mx_inv)) >= 1e-2:
                Mx = np.linalg.inv(Mx_inv)
            else:
                Mx = np.linalg.pinv(Mx_inv, rcond=1e-2)
            

            mujoco.mj_rne(model, data, 0, h)
            # print("Display the dimension of h : ", h.shape)
            # Compute generalized forces.
            # print("dimention of Mx : ", Mx.shape)
            # if(current_waypoint_index == len(acceleration_waypoints) - 1) :
            #     desired_acceleration = np.array([0,0,0,0,0,0])
            #     desired_twist = np.array([0,0,0,0,0,0])

            # else :
                
            desired_twist =  np.concatenate((current_velocity, np.zeros(3)))
            desired_acceleration = np.concatenate((current_acceleration, np.zeros(3)))
            meu = Mx @ (desired_acceleration +  jac1 @ M_inv[:7, :7] @ h[:7]  -  jac_dot[ : , :7] @ data.qvel[dof_ids])
            
            tau = jac1.T @ ( +1 * Kp * twist + Kd * (desired_twist - (jac1 @ data.qvel[dof_ids])) + meu)

            # Add joint task in nullspace.
            Jbar = M_inv[:7,:7] @ jac1.T @ Mx
            # print("size of q0 : ", q0.shape)
            # print(data.qpos[dof_ids])
            ddq = Kp_null * (q0[:7] - data.qpos[dof_ids]) - Kd_null * data.qvel[dof_ids]
            # print("ddq : ", ddq.shape)
            
            tau += (np.eye(7) - jac1.T @ Jbar.T) @ ddq
            # print("tau : ", tau.shape)

            # Add gravity compensation.
            if gravity_compensation:
                tau += data.qfrc_bias[dof_ids]

            # Set the control signal and step the simulation
            # print("actuator range : ", model.actuator_ctrlrange.shape)
            np.clip(tau, *model.actuator_ctrlrange[:7].T, out=tau)
            # model.actuator_ctrlrange[7] = 248
            data.ctrl[actuator_ids] = tau[actuator_ids]
            data.ctrl[7] = 255
            mujoco.mj_step(model, data)

            viewer.sync()
            current_angular_velocities =  data.qvel[dof_ids]
            end_effector_velocity = jac1 @ current_angular_velocities 

            current_position_in_x = data.site(site_id).xpos[0]
            current_position_in_y = data.site(site_id).xpos[1]
            current_position_in_z = data.site(site_id).xpos[2]
            
            current_time = time.time() + integration_dt
            current_velocity = (jac1 @ data.qvel[dof_ids])
            time_data.append(current_time)
            position_data_in_x.append(current_position_in_x)
            position_data_in_y.append(current_position_in_y)
            position_data_in_z.append(current_position_in_z)
            velocity_data_in_x.append(current_velocity[0])
            velocity_data_in_y.append(current_velocity[1])
            velocity_data_in_z.append(current_velocity[2])
            # distance_data.append(np.linalg.norm(current_position_in_x - waypoints[0][0]))
            target_data_in_x.append(interp_positions[current_waypoint_index][0])
            target_data_in_y.append(interp_positions[current_waypoint_index][1]) 
            target_data_in_z.append(interp_positions[current_waypoint_index][2])


            target_vel_in_x.append(interp_velocities[current_waypoint_index][0])
            target_vel_in_y.append(interp_velocities[current_waypoint_index][1]) 
            target_vel_in_z.append(interp_velocities[current_waypoint_index][2])

            dx_data.append(dx)

            if(current_waypoint_index < num_samples - 1) : 
                current_waypoint_index += 1

            time_until_next_step = dt - (time.time() - step_start) 
            if time_until_next_step > 0:
                time.sleep(time_until_next_step)

            

    # Plotting the collected data
    plt.figure(figsize=(12, 6))

    # Plotting the x coordinate of waypoints and current position
    plt.subplot(3, 2, 1)
    plt.plot(time_data, position_data_in_x, 'b-', label='Current Position', linewidth=2)
    plt.plot(time_data, target_data_in_x, "r--" , label = 'target_positions', linewidth = 2)
    plt.xlabel('Time (s)')
    plt.ylabel('Position (m)')
    plt.title('Position in X')
    plt.legend()
    plt.grid(True)

    plt.subplot(3, 2, 3)
    plt.plot(time_data, position_data_in_y, 'b-', label='Current Position', linewidth=2)
    plt.plot(time_data, target_data_in_y, "r--" , label = 'target_positions', linewidth = 2)
    plt.xlabel('Time (s)')
    plt.ylabel('Position (m)')
    plt.title('Position in y direction')
    plt.legend()
    plt.grid(True)


    plt.subplot(3, 2, 5)
    plt.plot(time_data, position_data_in_z, 'b-', label='Current Position', linewidth=2)
    plt.plot(time_data, target_data_in_z, "r--" , label = 'target_positions', linewidth = 2)
    plt.xlabel('Time (s)')
    plt.ylabel('Position (m)')
    plt.title('Position in z direction')
    plt.legend()
    plt.grid(True)
    # Plotting the velocity of the end effector
    plt.subplot(3, 2, 2)
    plt.plot(time_data, velocity_data_in_x, 'g-', label='Velocity', linewidth=2)
    plt.plot(time_data, target_vel_in_x, "r--" , label = 'target_velocity', linewidth = 2)
    plt.xlabel('Time (s)')
    plt.ylabel('Velocity (m/s)')
    plt.title('Velocity of end effector vs time in x ')
    plt.legend()
    plt.grid(True)

    plt.subplot(3, 2, 4)
    plt.plot(time_data, velocity_data_in_y, 'g-', label='Velocity', linewidth=2)
    plt.plot(time_data, target_vel_in_y, "r--" , label = 'target_velocity', linewidth = 2)
    plt.xlabel('Time (s)')
    plt.ylabel('Velocity (m/s)')
    plt.title('Velocity of end effector vs time in y')
    plt.legend()
    plt.grid(True)

    # plt.subplot(3,2,5)
    # # Plotting velocity vs distance covered in x-direction
    # plt.plot(distance_data, velocity_data_in_z, 'g-', label='Velocity vs Distance', linewidth=2)
    # plt.xlabel('Distance Covered in x-direction (m)')
    # plt.ylabel('Velocity in x-direction (m/s)')
    # plt.legend()
    # plt.grid(True)

    plt.subplot(3, 2, 6)
    plt.plot(time_data, velocity_data_in_z, 'g-', label='Velocity', linewidth=2)
    plt.plot(time_data, target_vel_in_z, "r--" , label = 'target_velocity', linewidth = 2)
    plt.xlabel('Time (s)')
    plt.ylabel('Velocity (m/s)')
    plt.title('Velocity of end effector vs time in z')
    plt.legend()
    plt.grid(True)

    # plt.subplot(4, 2, 7)
    # plt.plot(time_data, dx_data, 'g-', label='erro', linewidth=2)
    # # plt.plot(time_data, target_vel_in_z, "r--" , label = 'target_velocity', linewidth = 2)
    # plt.xlabel('Time (s)')
    # plt.ylabel('error (m/s)')
    # plt.title('error in position  of end effector vs time in z')
    # plt.legend()
    # plt.grid(True)


    plt.tight_layout()
    plt.show()
if __name__ == "__main__":
    main()
#potential function