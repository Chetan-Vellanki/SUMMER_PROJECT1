import numpy as np
impedance_pos = np.asarray([100.0, 100.0, 100.0])  # [N/m]
impedance_ori = np.asarray([50.0, 50.0, 50.0])  # [Nm/rad]

damping_ratio = 1

damping_pos = damping_ratio * 2 * np.sqrt(impedance_pos)
damping_ori = damping_ratio * 2 * np.sqrt(impedance_ori)

Kp = np.concatenate([impedance_pos, impedance_ori], axis=0)
Kd = np.concatenate([damping_pos, damping_ori], axis=0)

print("dimension of Kp : ", Kp.shape)

array = np.array([0.1,0.1,0.1,0.1,0.1,0.1])
array_new = Kp * array
print("shape of new array : ", array_new.shape)